# sync2

Peter McNamara's Sync II

This is an app with squares that move across the screen and get pushed by mouse clicks.
Each client gets their own square, and can click to move that square.

The squares are slightly jittery because my handing of delta time doesn't handle transmission time correctly.

https://github.com/icicle-tricycle/sync2
https://sync2.herokuapp.com/